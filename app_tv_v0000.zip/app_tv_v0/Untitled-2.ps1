
<#
  Edge 2 abas: Aba1=Link1, Aba2=Link2
  A cada N segundos:
    - atualiza a próxima aba em segundo plano (Page.reload) e depois troca (Page.bringToFront)

  Suporta:
    - Config padrão no código (CONFIG)
    - Sobrescrever por parâmetros
    - Execução em segundo plano (janela oculta) via relaunch Start-Process -WindowStyle Hidden [1](https://stackoverflow.com/questions/185575/powershell-equivalent-of-bash-ampersand-for-forking-running-background-proce)
    - CDP (remote debugging) usando --remote-debugging-port e --user-data-dir [2](https://code.visualstudio.com/docs/nodejs/browser-debugging)
    - Comandos CDP: Page.reload e Page.bringToFront [3](https://chromedevtools.github.io/devtools-protocol/tot/Page/)
#>

# ==========================================================
# CONFIG PADRÃO (EDITE AQUI)
# ==========================================================
$CONFIG = [ordered]@{
    Link1            = "https://banco.bradesco/html/classic/index.shtm"     # ex: "https://site1"
    Link2            = "https://vendaonline.bradescard.com.br/?canal=531&origem=913&tpopto=3&ptovda=17&campa=068&prod=7837"     # ex: "https://site2"
    IntervaloSegundos= 50
    LogPath          = (Join-Path $env:TEMP "EdgeTabSwap\edge-tabswap.log")
    RunHidden        = $true        # true = iniciar oculto por padrão
    DebugPort        = 9222
    ProfileDir       = (Join-Path $env:TEMP "Edge_Automation_Profile_CDP")
}
# ==========================================================

[CmdletBinding()]
param(
    # Parâmetros opcionais (se não informar, usa o CONFIG)
    [string]$Link1,
    [string]$Link2,
    [ValidateRange(1, 86400)]
    [int]$IntervaloSegundos,
    [string]$LogPath,
    [switch]$RunHidden,

    # interno (não mexer)
    [switch]$HiddenChild
)

# -------------------------
# APLICA CONFIG PADRÃO (somente quando parâmetro não foi passado)
# -------------------------
if (-not $PSBoundParameters.ContainsKey('Link1') -or [string]::IsNullOrWhiteSpace($Link1)) { $Link1 = $CONFIG.Link1 }
if (-not $PSBoundParameters.ContainsKey('Link2') -or [string]::IsNullOrWhiteSpace($Link2)) { $Link2 = $CONFIG.Link2 }
if (-not $PSBoundParameters.ContainsKey('IntervaloSegundos') -or $IntervaloSegundos -le 0) { $IntervaloSegundos = [int]$CONFIG.IntervaloSegundos }
if (-not $PSBoundParameters.ContainsKey('LogPath') -or [string]::IsNullOrWhiteSpace($LogPath)) { $LogPath = $CONFIG.LogPath }

# Switch: se não vier por parâmetro, usa o CONFIG.RunHidden
if (-not $PSBoundParameters.ContainsKey('RunHidden')) {
    $RunHidden = [bool]$CONFIG.RunHidden
}

$DebugPort = [int]$CONFIG.DebugPort
$EdgeProfileDir = [string]$CONFIG.ProfileDir

# -------------------------
# LOG
# -------------------------
function Initialize-Log {
    param([string]$Path)

    $dir = Split-Path -Parent $Path
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }

    # Rotação simples: > 5MB renomeia para .1
    if (Test-Path $Path) {
        $len = (Get-Item $Path).Length
        if ($len -gt 5MB) {
            $bak = "$Path.1"
            if (Test-Path $bak) { Remove-Item $bak -Force -ErrorAction SilentlyContinue }
            Rename-Item -Path $Path -NewName (Split-Path -Leaf $bak) -Force
        }
    }
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","WARN","ERROR")]
        [string]$Level = "INFO"
    )
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
    Add-Content -Path $LogPath -Value "[$ts][$Level] $Message"
}

Initialize-Log -Path $LogPath
Write-Log "Start. Link1='$Link1' Link2='$Link2' Intervalo=$IntervaloSegundos RunHidden=$RunHidden LogPath='$LogPath'"

# ----------------UNDO PLANO (OCULTO)
#
<#
.SYNOPSIS
  Abre Edge com 2 abas (Link1 e Link2) e alterna entre elas a cada N segundos,
  atualizando a aba seguinte antes de trocar (CDP/Page.reload + bringToFront).

.DESCRIPTION
  - "Defaults no código": Link1, Link2, LogPath e Intervalo ficam no param() (edite ali).
  - "Modo silencioso": inicia Edge minimizado/oculto e reduz prompts/notificações/áudio.
  - CDP: usa --remote-debugging-port e endpoint /json/list (DevTools Protocol). [4](https://www.chromium.org/developers/how-tos/run-chromium-with-flags/)
  - NÃO encerra o Edge do usuário: controla apenas o Edge iniciado por este script.

.PARAMETER Link1
  URL da aba 1 (default no código).

.PARAMETER Link2
  URL da aba 2 (default no código).

.PARAMETER IntervaloSegundos
  Intervalo em segundos entre as trocas (default no código).

.PARAMETER LogPath
  Caminho do arquivo de log (default no código).

.PARAMETER RunHidden
  Reexecuta o script em segundo plano (janela do PowerShell oculta) e encerra o processo atual.

.PARAMETER EdgeSilent
  Inicia Edge em modo silencioso (minimizado/oculto + flags anti prompts).

.PARAMETER EdgeWindowStyle
  WindowStyle do Edge quando EdgeSilent estiver ativo: Minimized (padrão) ou Hidden.

.NOTES
  IMPORTANTE: [CmdletBinding()] deve estar imediatamente antes de param() (sem código antes),
  senão ocorre ParserError "Unexpected attribute 'CmdletBinding'". [1](https://raspberrypi.stackexchange.com/questions/148421/autostarting-chromium-with-start-fullscreen-or-kiosk-options-breaks-the-appl)[2](https://github.com/MicrosoftDocs/edge-developer/blob/main/microsoft-edge/devtools/protocol/index.md)
#>

[CmdletBinding()]
param(
    # ============================
    # >>> EDITAR AQUI (defaults) <<
    # ============================
    [string]$Link1 = "https://vendaonline.bradescard.com.br/?canal=531&origem=913&tpopto=3&ptovda=17&campa=068&prod=7837",
    [string]$Link2 = "https://ge.globo.com/futebol/times/flamengo/noticia/2026/03/13/escalacao-do-flamengo-jardim-tera-mais-um-desfalque-e-deve-fazer-mudancas-contra-o-botafogo.ghtml",

    [ValidateRange(1, 86400)]
    [int]$IntervaloSegundos = 50,

    [string]$LogPath = (Join-Path $env:TEMP "EdgeTabSwap\edge-tabswap.log"),

    # Reexecuta Powershell oculto (útil em auto-start)
    [switch]$RunHidden,

    # Edge silencioso (minimizado/oculto + menos prompts/ruídos)
    [switch]$EdgeSilent,

    # Quando EdgeSilent, controla o estilo da janela do Edge
    [ValidateSet("Minimized","Hidden","Normal")]
    [string]$EdgeWindowStyle = "Minimized",

    # interno: evita loop de relaunch
    [switch]$HiddenChild
)

# =========================
# LOG
# =========================
function Initialize-Log {
    param([string]$Path)

    $dir = Split-Path -Parent $Path
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }

    # Rotação simples: se > 5MB, renomeia para .1 (sobrescreve)
    if (Test-Path $Path) {
        $len = (Get-Item $Path).Length
        if ($len -gt 5MB) {
            $bak = "$Path.1"
            if (Test-Path $bak) { Remove-Item $bak -Force -ErrorAction SilentlyContinue }
            Rename-Item -Path $Path -NewName (Split-Path -Leaf $bak) -Force
        }
    }
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","WARN","ERROR")]
        [string]$Level = "INFO"
    )
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
    $line = "[$ts][$Level] $Message"
    try {
        Add-Content -Path $LogPath -Value $line -Encoding UTF8
    } catch {
        # não interrompe por falha de log
    }
}

Initialize-Log -Path $LogPath
Write-Log "Iniciando. Link1='$Link1' Link2='$Link2' IntervaloSegundos=$IntervaloSegundos RunHidden=$RunHidden EdgeSilent=$EdgeSilent EdgeWindowStyle=$EdgeWindowStyle HiddenChild=$HiddenChild"

# =========================
# EXECUÇÃO EM SEGUNDO PLANO (PS OCULTO)
# =========================
if ($RunHidden -and -not $HiddenChild) {
    try {
        $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"")
        $argList += @("-Link1", "`"$Link1`"")
        $argList += @("-Link2", "`"$Link2`"")
        $argList += @("-IntervaloSegundos", "$IntervaloSegundos")
        $argList += @("-LogPath", "`"$LogPath`"")
        if ($EdgeSilent) { $argList += "-EdgeSilent" }
        if ($EdgeWindowStyle) { $argList += @("-EdgeWindowStyle", "$EdgeWindowStyle") }
        $argList += "-HiddenChild"

        Write-Log "Reexecutando em segundo plano (PowerShell oculto). Args: $($argList -join ' ')" "INFO"
        Start-Process -FilePath "powershell.exe" -ArgumentList $argList -WindowStyle Hidden | Out-Null
        Write-Log "Processo em segundo plano iniciado. Encerrando processo atual." "INFO"
    } catch {
        Write-Log "Falha ao reexecutar em segundo plano: $($_.Exception.Message)" "ERROR"
        throw
    }
    exit
}

# =========================
# EDGE / CDP
# =========================
$EdgeProfileDir = Join-Path $env:TEMP "Edge_Automation_Profile_CDP"

function Get-EdgePath {
    $candidatos = @(
        (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe"),
        (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe"),
        "msedge.exe"
    )
    foreach ($p in $candidatos) {
        if ($p -eq "msedge.exe") {
            $cmd = Get-Command msedge.exe -ErrorAction SilentlyContinue
            if ($cmd) { return $cmd.Source }
        } else {
            if (Test-Path $p) { return $p }
        }
    }
    throw "Não encontrei o executável do Edge (msedge.exe)."
}

function Get-FreeTcpPort {
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
    $listener.Start()
    $port = ($listener.LocalEndpoint).Port
    $listener.Stop()
    return $port
}

function Start-EdgeWithTabsCDP {
    param(
        [string]$EdgeExe,
        [string]$Url1,
        [string]$Url2,
        [int]$Port,
        [string]$ProfileDir,
        [switch]$Silent,
        [string]$WindowStyle
    )

    if (!(Test-Path $ProfileDir)) { New-Item -ItemType Directory -Path $ProfileDir -Force | Out-Null }

    # Flags para reduzir prompts/ruídos em automação (no-first-run etc). [3](https://stackoverflow.com/questions/14671051/what-is-cmdletbinding-and-how-does-it-work)
    $quietFlags = @(
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-notifications",
        "--mute-audio"
    )

    $args = @(
        "--remote-debugging-port=$Port",
        "--user-data-dir=`"$ProfileDir`"",
        "--new-window"
    )

    if ($Silent) {
        # Minimizando/ocultando a janela + flags de “silêncio”
        $args += "--start-minimized"
        $args += $quietFlags
    }

    $args += @("`"$Url1`"", "`"$Url2`"")

    $ws = if ($Silent) { $WindowStyle } else { "Normal" }

    Write-Log "Abrindo Edge com CDP na porta $Port. Silent=$Silent WindowStyle=$ws" "INFO"
    $proc = Start-Process -FilePath $EdgeExe -ArgumentList $args -WindowStyle $ws -PassThru
    return $proc
}

function Wait-ForCDP {
    param([int]$Port)
    # Endpoint padrão para listar targets (abas) no DevTools server. [4](https://www.chromium.org/developers/how-tos/run-chromium-with-flags/)
    $endpoint = "http://127.0.0.1:$Port/json/list"
    for ($i=0; $i -lt 200; $i++) {
        try {
            $r = Invoke-RestMethod -Uri $endpoint -Method GET -TimeoutSec 2
            if ($r) { return $true }
        } catch { }
        Start-Sleep -Milliseconds 150
    }
    throw "Não foi possível conectar ao endpoint CDP em $endpoint."
}

function Get-TabWebSocketUrls {
    param(
        [int]$Port,
        [string]$Url1,
        [string]$Url2
    )
    $endpoint = "http://127.0.0.1:$Port/json/list"
    $pages = Invoke-RestMethod -Uri $endpoint -Method GET

    $tabs = $pages | Where-Object { $_.type -eq "page" -and $_.url -and $_.url -notlike "devtools:*" }
    if (-not $tabs -or $tabs.Count -lt 2) {
        throw "Não consegui identificar 2 abas do tipo 'page' no CDP."
    }

    # tenta casar por URL (pode haver redirect)
    $tab1 = $tabs | Where-Object { $_.url -like "$Url1*" } | Select-Object -First 1
    $tab2 = $tabs | Where-Object { $_.url -like "$Url2*" } | Select-Object -First 1

    if (-not $tab1 -or -not $tab2) {
        $tab1 = $tabs | Select-Object -First 1
        $tab2 = $tabs | Select-Object -Skip 1 -First 1
        Write-Log "Aviso: não consegui casar URLs exatamente; usando as duas primeiras abas detectadas." "WARN"
    }

    [pscustomobject]@{
        Tab1Url = $tab1.url
        Tab2Url = $tab2.url
        Tab1Ws  = $tab1.webSocketDebuggerUrl
        Tab2Ws  = $tab2.webSocketDebuggerUrl
    }
}

function Connect-WebSocket {
    param([string]$WsUrl)

    Add-Type -AssemblyName System.Net.Http | Out-Null
    $ws = New-Object System.Net.WebSockets.ClientWebSocket
    $cts = New-Object System.Threading.CancellationTokenSource
    $ws.ConnectAsync([Uri]$WsUrl, $cts.Token).Wait()

    if ($ws.State -ne [System.Net.WebSockets.WebSocketState]::Open) {
        throw "Falha ao abrir WebSocket: $WsUrl"
    }
    return $ws
}

function Receive-WSMessage {
    param(
        [System.Net.WebSockets.ClientWebSocket]$Ws,
        [int]$TimeoutMs = 5000
    )

    $buffer = New-Object byte[] 65536
    $ct = [System.Threading.CancellationToken]::None
    $start = [Environment]::TickCount

    $sb = New-Object System.Text.StringBuilder
    while ($true) {
        if (([Environment]::TickCount - $start) -gt $TimeoutMs) { return $null }

        $seg = New-Object System.ArraySegment[byte] -ArgumentList @(,$buffer)
        $task = $Ws.ReceiveAsync($seg, $ct)
        $task.Wait(200) | Out-Null
        if (-not $task.IsCompleted) { continue }

        $result = $task.Result
        if ($result.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) { return $null }

        if ($result.Count -gt 0) {
            [void]$sb.Append([System.Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count))
        }

        if ($result.EndOfMessage) {
            return $sb.ToString()
        }
    }
}

function Send-CDP {
    param(
        [System.Net.WebSockets.ClientWebSocket]$Ws,
        [string]$Method,
        [hashtable]$Params = $null,
        [int]$Id,
        [int]$TimeoutMs = 4000
    )

    $payload = @{ id = $Id; method = $Method }
    if ($Params) { $payload.params = $Params }

    $json = ($payload | ConvertTo-Json -Compress)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $seg = New-Object System.ArraySegment[byte] -ArgumentList @(,$bytes)

    $ct = [System.Threading.CancellationToken]::None
    $Ws.SendAsync($seg, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $ct).Wait()

    # lê mensagens até achar resposta com o mesmo Id (eventos sem id são ignorados)
    $deadline = [Environment]::TickCount + $TimeoutMs
    while ([Environment]::TickCount -lt $deadline) {
        $msg = Receive-WSMessage -Ws $Ws -TimeoutMs 500
        if (-not $msg) { continue }

        try {
            $obj = $msg | ConvertFrom-Json -ErrorAction Stop
            if ($null -ne $obj.id -and $obj.id -eq $Id) { return $obj }
        } catch {
            # ignora fragmentos/ruídos
        }
    }

    # timeout não fatal
    return $null
}

# =========================
# SINGLE INSTANCE (mutex)
# =========================
$mutexName = "Global\EdgeTabSwapMutex"
$createdNew = $false
$mutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$createdNew)
if (-not $createdNew) {
    Write-Log "Outra instância do script já está rodando. Encerrando esta instância." "WARN"
    exit 2
}

# =========================
# EXECUÇÃO PRINCIPAL
# =========================
$ws1 = $null
$ws2 = $null
$edgeProc = $null
$DebugPort = Get-FreeTcpPort

try {
    $edgeExe = Get-EdgePath
    $edgeProc = Start-EdgeWithTabsCDP -EdgeExe $edgeExe -Url1 $Link1 -Url2 $Link2 -Port $DebugPort -ProfileDir $EdgeProfileDir -Silent:$EdgeSilent -WindowStyle $EdgeWindowStyle

    Write-Log "Edge iniciado. PID=$($edgeProc.Id). Aguardando CDP porta $DebugPort..." "INFO"
    Wait-ForCDP -Port $DebugPort

    $tabInfo = Get-TabWebSocketUrls -Port $DebugPort -Url1 $Link1 -Url2 $Link2
    Write-Log "Aba 1 detectada: $($tabInfo.Tab1Url)" "INFO"
    Write-Log "Aba 2 detectada: $($tabInfo.Tab2Url)" "INFO"

    $ws1 = Connect-WebSocket -WsUrl $tabInfo.Tab1Ws
    $ws2 = Connect-WebSocket -WsUrl $tabInfo.Tab2Ws
    Write-Log "WebSockets conectados (Tab1 e Tab2)." "INFO"

    $id = 1

    # habilita Page domain (melhora estabilidade em alguns casos)
    [void](Send-CDP -Ws $ws1 -Method "Page.enable" -Id $id); $id++
    [void](Send-CDP -Ws $ws2 -Method "Page.enable" -Id $id); $id++

    # começa na aba 1
    [void](Send-CDP -Ws $ws1 -Method "Page.bringToFront" -Id $id); $id++
    Write-Log "Iniciando na Aba 1." "INFO"

    while ($true) {
        if ($edgeProc -and $edgeProc.HasExited) {
            throw "Edge (PID=$($edgeProc.Id)) encerrou. Finalizando loop."
        }

        Start-Sleep -Seconds $IntervaloSegundos

        Write-Log "Ciclo: Atualizar Aba 2 (ignoreCache) e trazer para frente." "INFO"
        [void](Send-CDP -Ws $ws2 -Method "Page.reload" -Params @{ ignoreCache = $true } -Id $id); $id++
        [void](Send-CDP -Ws $ws2 -Method "Page.bringToFront" -Id $id); $id++

        if ($edgeProc -and $edgeProc.HasExited) { throw "Edge encerrou durante o ciclo." }

        Start-Sleep -Seconds $IntervaloSegundos

        Write-Log "Ciclo: Atualizar Aba 1 (ignoreCache) e trazer para frente." "INFO"
        [void](Send-CDP -Ws $ws1 -Method "Page.reload" -Params @{ ignoreCache = $true } -Id $id); $id++
        [void](Send-CDP -Ws $ws1 -Method "Page.bringToFront" -Id $id); $id++
    }
}
catch {
    Write-Log "Erro fatal: $($_.Exception.Message)" "ERROR"
    throw
}
finally {
    if ($ws1) { try { $ws1.Dispose() } catch {} }
    if ($ws2) { try { $ws2.Dispose() } catch {} }

    # Encerra SOMENTE o Edge aberto pelo script
    if ($edgeProc -and -not $edgeProc.HasExited) {
        Write-Log "Encerrando Edge do script (PID=$($edgeProc.Id))..." "INFO"
        try { $edgeProc.CloseMainWindow() | Out-Null } catch {}
        Start-Sleep -Milliseconds 800
        try { if (-not $edgeProc.HasExited) { $edgeProc | Stop-Process -Force } } catch {}
    }

    if ($mutex) { try { $mutex.ReleaseMutex() | Out-Null } catch {}; $mutex.Dispose() }
    Write-Log "Script finalizado (cleanup ok)." "INFO"
}
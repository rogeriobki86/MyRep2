<#
.SYNOPSIS
  Abre Edge com 2 abas (Link1 e Link2) e alterna entre elas a cada N segundos,
  atualizando a aba seguinte em segundo plano antes de trocar (CDP/Page.reload + bringToFront).

.DESCRIPTION
  - Suporta configuração "hardcoded" no próprio script (bloco CONFIG)
  - Ainda aceita parâmetros via linha de comando (parâmetros sobrescrevem o CONFIG)
  - Inicia o Edge em modo silencioso opcional (minimizado/oculto + flags anti-prompts)
  - Usa Edge DevTools Protocol (CDP) via --remote-debugging-port e endpoint /json/list.

  NOVO (opcional):
  - Pode validar se já existe Edge com janela aberta.
    Se sim, fecha todas as janelas/abas e então reinicia o Edge do script.

.PARAMETER Link1
  URL da aba 1.

.PARAMETER Link2
  URL da aba 2.

.PARAMETER IntervaloSegundos
  Intervalo em segundos entre as trocas.

.PARAMETER LogPath
  Caminho do arquivo de log.

.PARAMETER RunHidden
  Reexecuta o script em segundo plano (janela do PowerShell oculta) e encerra o processo atual.

.PARAMETER EdgeSilent
  Inicia o Edge minimizado/oculto e com flags para reduzir prompts (no-first-run, etc).

.PARAMETER RestartEdgeIfOpen
  Se existir Edge com janela aberta (do usuário), tenta fechar todas as janelas/abas
  antes de iniciar o Edge controlado por este script.

.PARAMETER ForceKillEdge
  Usado junto com RestartEdgeIfOpen:
  além do fechamento gracioso, força encerramento de TODOS os processos msedge (inclui background).
  Use com cuidado: pode interromper sessões, downloads e páginas do usuário.

.NOTES
  Por padrão NÃO interfere em instâncias do Edge do usuário.
  Só interfere se você passar -RestartEdgeIfOpen (e opcionalmente -ForceKillEdge).
#>

# ==========================================================
# IMPORTANTE:
# Em scripts (.ps1), [CmdletBinding()] e param() devem vir
# antes de qualquer código executável (variáveis, funções, etc).
# Comentários e linhas em branco podem vir antes.
# ==========================================================
[CmdletBinding()]
param(
    # Agora NÃO é Mandatory. Se não vier parâmetro, usa CONFIG.
    [string]$Link1,

    [string]$Link2,

    [ValidateRange(1, 86400)]
    [int]$IntervaloSegundos,

    [string]$LogPath,

    [switch]$RunHidden,

    [switch]$EdgeSilent,

    # NOVO
    [switch]$RestartEdgeIfOpen,
    [switch]$ForceKillEdge,

    # interno: evita loop de relaunch
    [switch]$HiddenChild
)

# =========================
# ======= CONFIG ==========
# =========================
$CFG_Link1             = "https://g1.globo.com/politica/blog/andreia-sadi/post/2026/03/13/vorcaro-troca-de-advogado-apos-maioria-no-stf-e-abre-caminho-para-delacao-premiada.ghtml"
$CFG_Link2             = "https://vendaonline.bradescard.com.br/?canal=531&origem=913&tpopto=3&ptovda=17&campa=068&prod=7837"
$CFG_IntervaloSegundos = 5

<#$CFG_LogPath           = Join-Path $env:TEMP "EdgeTabSwap\edge-tabswap.log"#>
$CFG_LogDir            = "C:\ProgramData\app\logs"
$CFG_LogPath           = Join-Path $CFG_LogDir ("logs_teste_{0}.log" -f (Get-Date -Format "yyyy_MM_dd_HH_mm"))

# Se quiser iniciar sempre silencioso por padrão, troque para $true
$CFG_EdgeSilentDefault = $true

# NOVO: se quiser habilitar reinício automático do Edge quando houver janela aberta:
$CFG_RestartEdgeIfOpenDefault = $true

# NOVO: se quiser matar TODOS os msedge (inclui background) ao reiniciar:
$CFG_ForceKillEdgeDefault     = $false
# =========================

# -------------------------
# RESOLVE DEFAULTS (CONFIG vs PARAM)
# -------------------------
if ([string]::IsNullOrWhiteSpace($Link1)) { $Link1 = $CFG_Link1 }
if ([string]::IsNullOrWhiteSpace($Link2)) { $Link2 = $CFG_Link2 }

if (-not $PSBoundParameters.ContainsKey('IntervaloSegundos')) { $IntervaloSegundos = $CFG_IntervaloSegundos }
if (-not $PSBoundParameters.ContainsKey('LogPath'))          { $LogPath = $CFG_LogPath }

# EdgeSilent: se não veio parâmetro, usa default do CONFIG
if (-not $PSBoundParameters.ContainsKey('EdgeSilent')) {
    $EdgeSilent = [bool]$CFG_EdgeSilentDefault
}

# NOVO: RestartEdgeIfOpen / ForceKillEdge defaults
if (-not $PSBoundParameters.ContainsKey('RestartEdgeIfOpen')) {
    $RestartEdgeIfOpen = [bool]$CFG_RestartEdgeIfOpenDefault
}
if (-not $PSBoundParameters.ContainsKey('ForceKillEdge')) {
    $ForceKillEdge = [bool]$CFG_ForceKillEdgeDefault
}

# -------------------------
# LOG
# -------------------------
function Initialize-Log {
    param([string]$Path)

    $dir = Split-Path -Parent $Path
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }

    # Rotação simples: se > 5MB, renomeia para .1 (sobrescreve)
    if (Test-Path $Path) {
        $len = (Get-Item $Path).Length
        if ($len -gt 5MB) {
            $bak = "$Path.1"
            if (Test-Path $bak) { Remove-Item $bak -Force -ErrorAction SilentlyContinue }
            Rename-Item -Path $Path -NewName (Split-Path -Leaf $bak) -Force
        }
    }
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","WARN","ERROR")]
        [string]$Level = "INFO"
    )
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
    $line = "[$ts][$Level] $Message"
    try {
        Add-Content -Path $LogPath -Value $line -Encoding UTF8
    } catch {
        # fallback silencioso
    }
}

Initialize-Log -Path $LogPath
Write-Log "Inicializando APP_TV ... Carregando CONFIGS ..... Link_1='$Link1' || Link_2='$Link2' || IntervaloSegundos=$IntervaloSegundos || RunHidden=$RunHidden || EdgeSilent=$EdgeSilent || RestartEdgeIfOpen=$RestartEdgeIfOpen || ForceKillEdge=$ForceKillEdge || HiddenChild=$HiddenChild"

# -------------------------
# EXECUÇÃO EM SEGUNDO PLANO (CONSOLE OCULTO)
# -------------------------
if ($RunHidden -and -not $HiddenChild) {
    try {
        $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"")
        $argList += @("-Link1", "`"$Link1`"")
        $argList += @("-Link2", "`"$Link2`"")
        $argList += @("-IntervaloSegundos", "$IntervaloSegundos")
        $argList += @("-LogPath", "`"$LogPath`"")
        if ($EdgeSilent)          { $argList += @("-EdgeSilent") }
        if ($RestartEdgeIfOpen)   { $argList += @("-RestartEdgeIfOpen") }
        if ($ForceKillEdge)       { $argList += @("-ForceKillEdge") }
        $argList += @("-HiddenChild")

        Write-Log "Reexecutando em segundo plano (PS oculto). Args: $($argList -join ' ')" "INFO"
        Start-Process -FilePath "powershell.exe" -ArgumentList $argList -WindowStyle Hidden | Out-Null
        Write-Log "Processo em segundo plano iniciado. Encerrando processo atual." "INFO"
    } catch {
        Write-Log "Falha ao reexecutar em segundo plano: $($_.Exception.Message)" "ERROR"
        throw
    }
    exit
}

# -------------------------
# EDGE / CDP
# -------------------------
$EdgeProfileDir = Join-Path $env:TEMP "Edge_Automation_Profile_CDP"

function Get-EdgePath {
    $candidatos = @(
        (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe"),
        (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe"),
        "msedge.exe"
    )
    foreach ($p in $candidatos) {
        if ($p -eq "msedge.exe") {
            $cmd = Get-Command msedge.exe -ErrorAction SilentlyContinue
            if ($cmd) { return $cmd.Source }
        } else {
            if (Test-Path $p) { return $p }
        }
    }
    throw "Não encontrei o executável do Edge (msedge.exe)."
}

function Get-FreeTcpPort {
    # Reserva uma porta livre do SO e libera em seguida
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
    $listener.Start()
    $port = ($listener.LocalEndpoint).Port
    $listener.Stop()
    return $port
}

function Start-EdgeWithTabsCDP {
    param(
        [string]$EdgeExe,
        [string]$Url1,
        [string]$Url2,
        [int]$Port,
        [string]$ProfileDir,
        [switch]$Silent
    )

    if (!(Test-Path $ProfileDir)) { New-Item -ItemType Directory -Path $ProfileDir | Out-Null }

    # Flags "silenciosos": reduzem prompts e ruídos visuais/sonoros.
    $quietFlags = @(
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-notifications",
        "--mute-audio"
    )

    $args = @(
        "--remote-debugging-port=$Port",
        "--user-data-dir=`"$ProfileDir`"",
        "--new-window"
    )

    if ($Silent) {
        $args += "--start-minimized"
        $args += $quietFlags
    }

    $args += @(
        "`"$Url1`"",
        "`"$Url2`""
    )

    Write-Log "Abrindo Edge (CDP porta $Port) com 2 abas. Silent=$Silent" "INFO"

    $windowStyle = if ($Silent) { "Minimized" } else { "Normal" }

    # PassThru para controlar SOMENTE esta instância
    $proc = Start-Process -FilePath $EdgeExe -ArgumentList $args -WindowStyle $windowStyle -PassThru
    return $proc
}

function Wait-ForCDP {
    param([int]$Port)
    $endpoint = "http://127.0.0.1:$Port/json/list"
    for ($i=0; $i -lt 200; $i++) {
        try {
            $r = Invoke-RestMethod -Uri $endpoint -Method GET -TimeoutSec 2
            if ($r) { return $true }
        } catch { }
        Start-Sleep -Milliseconds 150
    }
    throw "Não foi possível conectar ao endpoint CDP em $endpoint."
}

function Get-TabWebSocketUrls {
    param(
        [int]$Port,
        [string]$Url1,
        [string]$Url2
    )
    $endpoint = "http://127.0.0.1:$Port/json/list"
    $pages = Invoke-RestMethod -Uri $endpoint -Method GET

    $tabs = $pages | Where-Object { $_.type -eq "page" -and $_.url -and $_.url -notlike "devtools:*" }
    if (-not $tabs -or $tabs.Count -lt 2) {
        throw "Não consegui identificar 2 abas do tipo 'page' no CDP."
    }

    # tenta casar por URL (pode haver redirecionamento)
    $tab1 = $tabs | Where-Object { $_.url -like "$Url1*" } | Select-Object -First 1
    $tab2 = $tabs | Where-Object { $_.url -like "$Url2*" } | Select-Object -First 1

    if (-not $tab1 -or -not $tab2) {
        $tab1 = $tabs | Select-Object -First 1
        $tab2 = $tabs | Select-Object -Skip 1 -First 1
        Write-Log "Aviso: não consegui casar URLs exatamente; usando as duas primeiras abas detectadas." "WARN"
    }

    [pscustomobject]@{
        Tab1Url = $tab1.url
        Tab2Url = $tab2.url
        Tab1Ws  = $tab1.webSocketDebuggerUrl
        Tab2Ws  = $tab2.webSocketDebuggerUrl
    }
}

function Connect-WebSocket {
    param([string]$WsUrl)

    Add-Type -AssemblyName System.Net.Http | Out-Null
    $ws = New-Object System.Net.WebSockets.ClientWebSocket
    $cts = New-Object System.Threading.CancellationTokenSource
    $ws.ConnectAsync([Uri]$WsUrl, $cts.Token).Wait()

    if ($ws.State -ne [System.Net.WebSockets.WebSocketState]::Open) {
        throw "Falha ao abrir WebSocket: $WsUrl"
    }
    return $ws
}

function Send-CDP {
    param(
        [System.Net.WebSockets.ClientWebSocket]$Ws,
        [string]$Method,
        [hashtable]$Params = $null,
        [int]$Id
    )

    $payload = @{ id = $Id; method = $Method }
    if ($Params) { $payload.params = $Params }

    $json = ($payload | ConvertTo-Json -Compress)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $seg = New-Object System.ArraySegment[byte] -ArgumentList @(,$bytes)

    $ct = [System.Threading.CancellationToken]::None
    $Ws.SendAsync($seg, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $ct).Wait()

    # Lê até encontrar a resposta do mesmo Id (eventos sem Id são ignorados)
    $buffer = New-Object byte[] 65536
    while ($true) {
        $recvSeg = New-Object System.ArraySegment[byte] -ArgumentList @(,$buffer)
        $result = $Ws.ReceiveAsync($recvSeg, $ct).Result

        if ($result.Count -gt 0) {
            $text = [System.Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count)
            try {
                $obj = $text | ConvertFrom-Json
                if ($obj.id -eq $Id) { break }
            } catch {
                # evento ou fragmento; ignora
            }
        }
        # continua lendo até bater o Id
    }
}

# -------------------------
# NOVO: DETECTAR EDGE "ABERTO" E REINICIAR (OPCIONAL)
# -------------------------
function Get-EdgeUiProcesses {
    # “Edge aberto” = pelo menos uma janela visível (não só processo em background)
    try {
        $procs = Get-Process -Name msedge -ErrorAction SilentlyContinue
        if (-not $procs) { return @() }

        $ui = $procs | Where-Object {
            ($_.MainWindowHandle -ne 0) -or (-not [string]::IsNullOrWhiteSpace($_.MainWindowTitle))
        }
        return @($ui)
    } catch {
        return @()
    }
}

function Stop-EdgeGracefully {
    param(
        [int]$WaitSeconds = 8,
        [switch]$ForceKillAll
    )

    $ui = Get-EdgeUiProcesses
    if (-not $ui -or $ui.Count -eq 0) {
        Write-Log "Não há janelas do Edge abertas (apenas background, ou nada). Nada a reiniciar." "INFO"
        return
    }

    Write-Log "Detectadas $($ui.Count) janelas do Edge abertas. Fechando para reiniciar..." "WARN"

    foreach ($p in $ui) {
        try {
            Write-Log "Solicitando fechamento gracioso do Edge. PID=$($p.Id) Title='$($p.MainWindowTitle)'" "INFO"
            $null = $p.CloseMainWindow()
        } catch {
            Write-Log "Falha ao chamar CloseMainWindow no PID=$($p.Id): $($_.Exception.Message)" "WARN"
        }
    }

    # aguarda fechar janelas
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $WaitSeconds) {
        Start-Sleep -Milliseconds 300
        $stillUi = Get-EdgeUiProcesses
        if (-not $stillUi -or $stillUi.Count -eq 0) { break }
    }
    $sw.Stop()

    $stillUi = Get-EdgeUiProcesses
    if ($stillUi -and $stillUi.Count -gt 0) {
        Write-Log "Ainda existem janelas do Edge após $WaitSeconds s. Forçando encerramento dos PIDs: $($stillUi.Id -join ',')" "WARN"
        try { $stillUi | Stop-Process -Force -ErrorAction SilentlyContinue } catch {}
    }

    if ($ForceKillAll) {
        # Mata todos os msedge.exe (inclui processos em background)
        $all = Get-Process -Name msedge -ErrorAction SilentlyContinue
        if ($all) {
            Write-Log "ForceKillEdge habilitado: encerrando TODOS os processos msedge (inclui background)." "WARN"
            try { $all | Stop-Process -Force -ErrorAction SilentlyContinue } catch {}
        }
    }

    Write-Log "Edge do usuário fechado (abas/janelas). Prosseguindo com reinício pelo script." "INFO"
}

# -------------------------
# SINGLE INSTANCE (mutex)
# -------------------------
# Observação: em alguns ambientes, 'Global\' pode exigir privilégios.
# Aqui tentamos Global e, se falhar, caímos para Local.
$createdNew = $false
$mutex = $null

try {
    $mutexName = "Global\EdgeTabSwapMutex"
    $mutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$createdNew)
} catch {
    $mutexName = "Local\EdgeTabSwapMutex"
    $mutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$createdNew)
}

if (-not $createdNew) {
    Write-Log "Outra instância do script já está rodando. Encerrando esta instância." "WARN"
    exit 2
}

# -------------------------
# NOVO: Reiniciar Edge do usuário se solicitado (após mutex)
# -------------------------
if ($RestartEdgeIfOpen) {
    Stop-EdgeGracefully -WaitSeconds 8 -ForceKillAll:$ForceKillEdge
}

# -------------------------
# EXECUÇÃO PRINCIPAL
# -------------------------
$ws1 = $null
$ws2 = $null
$edgeProc = $null
$DebugPort = Get-FreeTcpPort

try {
    $edgeExe = Get-EdgePath
    $edgeProc = Start-EdgeWithTabsCDP -EdgeExe $edgeExe -Url1 $Link1 -Url2 $Link2 -Port $DebugPort -ProfileDir $EdgeProfileDir -Silent:$EdgeSilent

    Write-Log "Edge iniciado PID=$($edgeProc.Id). Aguardando CDP na porta $DebugPort..." "INFO"

    Wait-ForCDP -Port $DebugPort
    $tabInfo = Get-TabWebSocketUrls -Port $DebugPort -Url1 $Link1 -Url2 $Link2

    Write-Log "Aba 1 detectada: $($tabInfo.Tab1Url)" "INFO"
    Write-Log "Aba 2 detectada: $($tabInfo.Tab2Url)" "INFO"

    $ws1 = Connect-WebSocket -WsUrl $tabInfo.Tab1Ws
    $ws2 = Connect-WebSocket -WsUrl $tabInfo.Tab2Ws
    Write-Log "WebSockets conectados (Tab1 e Tab2)." "INFO"

    $id = 1

    # Opcional: habilita Page domain (em alguns cenários melhora estabilidade)
    Send-CDP -Ws $ws1 -Method "Page.enable" -Id $id; $id++
    Send-CDP -Ws $ws2 -Method "Page.enable" -Id $id; $id++

    # Garante início focado na Aba 1
    Send-CDP -Ws $ws1 -Method "Page.bringToFront" -Id $id; $id++
    Write-Log "Iniciando na Aba 1." "INFO"

    while ($true) {
        Start-Sleep -Seconds $IntervaloSegundos

        Write-Log "Ciclo: Atualizar Aba 2 (background) e trazer para frente." "INFO"
        Send-CDP -Ws $ws2 -Method "Page.reload" -Params @{ ignoreCache = $true } -Id $id; $id++
        Send-CDP -Ws $ws2 -Method "Page.bringToFront" -Id $id; $id++

        Start-Sleep -Seconds $IntervaloSegundos

        Write-Log "Ciclo: Atualizar Aba 1 (background) e trazer para frente." "INFO"
        Send-CDP -Ws $ws1 -Method "Page.reload" -Params @{ ignoreCache = $true } -Id $id; $id++
        Send-CDP -Ws $ws1 -Method "Page.bringToFront" -Id $id; $id++
    }
}
catch {
    Write-Log "Erro fatal: $($_.Exception.Message)" "ERROR"
    throw
}
finally {
    if ($ws1) { $ws1.Dispose() }
    if ($ws2) { $ws2.Dispose() }

    # encerra somente o Edge aberto por este script
    if ($edgeProc -and -not $edgeProc.HasExited) {
        Write-Log "Encerrando Edge do script (PID=$($edgeProc.Id))..." "INFO"
        try { $edgeProc.CloseMainWindow() | Out-Null } catch {}
        Start-Sleep -Milliseconds 800
        try { if (-not $edgeProc.HasExited) { $edgeProc | Stop-Process -Force } } catch {}
    }

    if ($mutex) {
        try { $mutex.ReleaseMutex() | Out-Null } catch {}
        $mutex.Dispose()
    }
    Write-Log "Script finalizado (cleanup ok)." "INFO"
}
<#
.SYNOPSIS
  Abre Microsoft Edge e alterna entre Link1 e Link2 a cada N segundos via CDP.
  Suporta modo silencioso e modo Kiosk/tela cheia (TV/painel).

.PARAMETER KioskFullscreen
  Ativa diretamente o Kiosk em tela cheia (--kiosk + --edge-kiosk-type=fullscreen). [1](https://raspberrypi.stackexchange.com/questions/148421/autostarting-chromium-with-start-fullscreen-or-kiosk-options-breaks-the-appl)[2](https://textslashplain.com/2022/01/05/edge-command-line-arguments/)

.PARAMETER EdgeSilent
  Reduz prompts e ruídos (ex.: --no-first-run) e pode iniciar minimizado no modo normal. [1](https://raspberrypi.stackexchange.com/questions/148421/autostarting-chromium-with-start-fullscreen-or-kiosk-options-breaks-the-appl)[3](https://learn.microsoft.com/en-us/answers/questions/847425/options-for-opening-edge-full-screen)
#>

[CmdletBinding()]
param(
    # ====== DEFAULTS NO CÓDIGO (edite aqui) ======
    [string]$Link1 = "https://vendaonline.bradescard.com.br/?canal=531&origem=913&tpopto=3&ptovda=17&campa=068&prod=7837",
    [string]$Link2 = "https://ge.globo.com/futebol/times/flamengo/noticia/2026/03/13/escalacao-do-flamengo-jardim-tera-mais-um-desfalque-e-deve-fazer-mudancas-contra-o-botafogo.ghtml",
  
    [ValidateRange(1, 86400)]
    [int]$IntervaloSegundos = 50,

    [string]$LogPath = (Join-Path $env:TEMP "EdgeTabSwap\edge-tabswap.log"),
    # ============================================

    [switch]$RunHidden,

    # Ativa “silencioso” via parâmetro
    [switch]$EdgeSilent,

    # NOVO: Ativa direto o kiosk fullscreen via parâmetro
    [switch]$KioskFullscreen,

    # Mantido: modo kiosk genérico + tipo
    [switch]$Kiosk,

    [ValidateSet("fullscreen","public-browsing")]
    [string]$KioskType = "fullscreen",

    # Flag oficial de idle timeout (0..1440; 0 desliga) [1](https://raspberrypi.stackexchange.com/questions/148421/autostarting-chromium-with-start-fullscreen-or-kiosk-options-breaks-the-appl)
    [ValidateRange(0, 1440)]
    [int]$KioskIdleTimeoutMinutes = 0,

    # interno: evita loop de relaunch
    [switch]$HiddenChild
)

# -------------------------
# RESOLVE FLAGS (KioskFullscreen => Kiosk + fullscreen)
# -------------------------
if ($KioskFullscreen) {
    $Kiosk = $true
    $KioskType = "fullscreen"
}

# -------------------------
# LOG
# -------------------------
function Initialize-Log {
    param([string]$Path)
    $dir = Split-Path -Parent $Path
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }

    # Rotação simples: se > 5MB, renomeia para .1
    if (Test-Path $Path) {
        $len = (Get-Item $Path).Length
        if ($len -gt 5MB) {
            $bak = "$Path.1"
            if (Test-Path $bak) { Remove-Item $bak -Force -ErrorAction SilentlyContinue }
            Rename-Item -Path $Path -NewName (Split-Path -Leaf $bak) -Force
        }
    }
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","WARN","ERROR")]
        [string]$Level = "INFO"
    )
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
    $line = "[$ts][$Level] $Message"
    try { Add-Content -Path $LogPath -Value $line -Encoding UTF8 } catch {}
}

Initialize-Log -Path $LogPath
Write-Log "Iniciando. Link1='$Link1' Link2='$Link2' Intervalo=$IntervaloSegundos RunHidden=$RunHidden EdgeSilent=$EdgeSilent Kiosk=$Kiosk KioskType=$KioskType KioskFullscreen=$KioskFullscreen IdleMin=$KioskIdleTimeoutMinutes"

# -------------------------
# EXECUÇÃO EM SEGUNDO PLANO (PS OCULTO)
# -------------------------
if ($RunHidden -and -not $HiddenChild) {
    try {
        $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"")
        $argList += @("-Link1", "`"$Link1`"", "-Link2", "`"$Link2`"")
        $argList += @("-IntervaloSegundos", "$IntervaloSegundos", "-LogPath", "`"$LogPath`"")

        if ($EdgeSilent)      { $argList += "-EdgeSilent" }
        if ($Kiosk)           { $argList += "-Kiosk" }
        if ($KioskFullscreen) { $argList += "-KioskFullscreen" }

        $argList += @("-KioskType", "$KioskType", "-KioskIdleTimeoutMinutes", "$KioskIdleTimeoutMinutes")
        $argList += "-HiddenChild"

        Write-Log "Reexecutando em PS oculto. Args: $($argList -join ' ')" "INFO"
        Start-Process -FilePath "powershell.exe" -ArgumentList $argList -WindowStyle Hidden | Out-Null
        Write-Log "Child oculto iniciado; encerrando processo atual." "INFO"
    } catch {
        Write-Log "Falha ao reexecutar oculto: $($_.Exception.Message)" "ERROR"
        throw
    }
    exit
}

# -------------------------
# EDGE / CDP
# -------------------------
$EdgeProfileDir = Join-Path $env:TEMP "Edge_Automation_Profile_CDP"

function Get-EdgePath {
    $candidatos = @(
        (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe"),
        (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe"),
        "msedge.exe"
    )
    foreach ($p in $candidatos) {
        if ($p -eq "msedge.exe") {
            $cmd = Get-Command msedge.exe -ErrorAction SilentlyContinue
            if ($cmd) { return $cmd.Source }
        } else {
            if (Test-Path $p) { return $p }
        }
    }
    throw "Não encontrei o executável do Edge (msedge.exe)."
}

function Get-FreeTcpPort {
    $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, 0)
    $listener.Start()
    $port = ($listener.LocalEndpoint).Port
    $listener.Stop()
    return $port
}

function Start-EdgeCDP {
    param(
        [string]$EdgeExe,
        [string]$UrlStart,
        [int]$Port,
        [string]$ProfileDir,
        [switch]$Silent,
        [switch]$KioskMode,
        [string]$KioskModeType,
        [int]$IdleTimeoutMinutes
    )

    if (!(Test-Path $ProfileDir)) { New-Item -ItemType Directory -Path $ProfileDir -Force | Out-Null }

    $args = @(
        "--remote-debugging-port=$Port",
        "--user-data-dir=`"$ProfileDir`""
    )

    # EdgeSilent: usa --no-first-run (flag citada em doc de kiosk) [1](https://raspberrypi.stackexchange.com/questions/148421/autostarting-chromium-with-start-fullscreen-or-kiosk-options-breaks-the-appl)
    if ($Silent) {
        $args += "--no-first-run"   # reduzir telas de primeira execução
        $args += "--no-default-browser-check"
    }

    if ($KioskMode) {
        # Flags oficiais do kiosk [1](https://raspberrypi.stackexchange.com/questions/148421/autostarting-chromium-with-start-fullscreen-or-kiosk-options-breaks-the-appl)[2](https://textslashplain.com/2022/01/05/edge-command-line-arguments/)
        $args += "--kiosk"
        $args += "`"$UrlStart`""
        $args += "--edge-kiosk-type=$KioskModeType"

        if ($IdleTimeoutMinutes -gt 0) {
            $args += "--kiosk-idle-timeout-minutes=$IdleTimeoutMinutes"
        }

        $windowStyle = "Normal"
    }
    else {
        $args += "--new-window"
        $args += "`"$UrlStart`""
        $windowStyle = if ($Silent) { "Minimized" } else { "Normal" }
    }

    Write-Log "Iniciando Edge. CDP=$Port Kiosk=$KioskMode Type=$KioskModeType Silent=$Silent" "INFO"
    return (Start-Process -FilePath $EdgeExe -ArgumentList $args -WindowStyle $windowStyle -PassThru)
}

function Wait-ForCDP {
    param([int]$Port)
    $endpoint = "http://127.0.0.1:$Port/json/list"
    for ($i=0; $i -lt 200; $i++) {
        try {
            $r = Invoke-RestMethod -Uri $endpoint -Method GET -TimeoutSec 2
            if ($r) { return $true }
        } catch { }
        Start-Sleep -Milliseconds 150
    }
    throw "Não foi possível conectar ao endpoint CDP em $endpoint"
}

function Get-FirstPageTarget {
    param([int]$Port)
    $endpoint = "http://127.0.0.1:$Port/json/list"
    $pages = Invoke-RestMethod -Uri $endpoint -Method GET
    $tab = $pages | Where-Object { $_.type -eq "page" -and $_.url -and $_.url -notlike "devtools:*" } | Select-Object -First 1
    if (-not $tab) { throw "Não encontrei target do tipo 'page' no CDP." }
    return $tab
}

function Connect-WebSocket {
    param([string]$WsUrl)
    Add-Type -AssemblyName System.Net.Http | Out-Null
    $ws = New-Object System.Net.WebSockets.ClientWebSocket
    $cts = New-Object System.Threading.CancellationTokenSource
    $ws.ConnectAsync([Uri]$WsUrl, $cts.Token).Wait()
    if ($ws.State -ne [System.Net.WebSockets.WebSocketState]::Open) {
        throw "Falha ao abrir WebSocket: $WsUrl"
    }
    return $ws
}

function Send-CDP {
    param(
        [System.Net.WebSockets.ClientWebSocket]$Ws,
        [string]$Method,
        [hashtable]$Params = $null,
        [int]$Id,
        [int]$TimeoutMs = 4000
    )

    $payload = @{ id = $Id; method = $Method }
    if ($Params) { $payload.params = $Params }

    $json = ($payload | ConvertTo-Json -Compress)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $seg = New-Object System.ArraySegment[byte] -ArgumentList @(,$bytes)

    $ct = [System.Threading.CancellationToken]::None
    $Ws.SendAsync($seg, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $ct).Wait()

    # Lê até achar resposta com o mesmo Id (ignora eventos sem id)
    $buffer = New-Object byte[] 65536
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    while ($sw.ElapsedMilliseconds -lt $TimeoutMs) {
        $recvSeg = New-Object System.ArraySegment[byte] -ArgumentList @(,$buffer)
        $task = $Ws.ReceiveAsync($recvSeg, $ct)

        if (-not $task.Wait(500)) { continue }

        $result = $task.Result
        if ($result.Count -le 0) { continue }

        $text = [System.Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count)
        try {
            $obj = $text | ConvertFrom-Json
            if ($obj.id -eq $Id) { break }
        } catch {
            # evento/fragmento
        }
    }
}

# -------------------------
# SINGLE INSTANCE (mutex)
# -------------------------
$mutexName = "Global\EdgeTabSwapMutex"
$createdNew = $false
$mutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$createdNew)
if (-not $createdNew) {
    Write-Log "Outra instância já está rodando. Encerrando." "WARN"
    exit 2
}

# -------------------------
# EXECUÇÃO PRINCIPAL
# -------------------------
$ws = $null
$edgeProc = $null
$DebugPort = Get-FreeTcpPort

try {
    $edgeExe = Get-EdgePath

    # Em Kiosk fullscreen, alterna na MESMA aba via Page.navigate (painel/TV)
    $edgeProc = Start-EdgeCDP -EdgeExe $edgeExe -UrlStart $Link1 -Port $DebugPort -ProfileDir $EdgeProfileDir `
                             -Silent:$EdgeSilent -KioskMode:$Kiosk -KioskModeType $KioskType -IdleTimeoutMinutes $KioskIdleTimeoutMinutes

    Write-Log "Edge iniciado PID=$($edgeProc.Id). Aguardando CDP porta $DebugPort..." "INFO"
    Wait-ForCDP -Port $DebugPort

    $tab = Get-FirstPageTarget -Port $DebugPort
    Write-Log "Target page url=$($tab.url)" "INFO"

    $ws = Connect-WebSocket -WsUrl $tab.webSocketDebuggerUrl
    Write-Log "WebSocket conectado." "INFO"

    $id = 1
    Send-CDP -Ws $ws -Method "Page.enable" -Id $id; $id++

    if (-not $Kiosk) {
        Send-CDP -Ws $ws -Method "Page.bringToFront" -Id $id; $id++
    }

    $current = 1
    while ($true) {
        Start-Sleep -Seconds $IntervaloSegundos

        if ($current -eq 1) {
            Write-Log "Alternando para Link2 via Page.navigate" "INFO"
            Send-CDP -Ws $ws -Method "Page.navigate" -Params @{ url = $Link2 } -Id $id; $id++
            $current = 2
        } else {
            Write-Log "Alternando para Link1 via Page.navigate" "INFO"
            Send-CDP -Ws $ws -Method "Page.navigate" -Params @{ url = $Link1 } -Id $id; $id++
            $current = 1
        }
    }
}
catch {
    Write-Log "Erro fatal: $($_.Exception.Message)" "ERROR"
    throw
}
finally {
    if ($ws) { try { $ws.Dispose() } catch {} }

    if ($edgeProc -and -not $edgeProc.HasExited) {
        Write-Log "Encerrando Edge do script (PID=$($edgeProc.Id))..." "INFO"
        try { $edgeProc.CloseMainWindow() | Out-Null } catch {}
        Start-Sleep -Milliseconds 800
        try { if (-not $edgeProc.HasExited) { $edgeProc | Stop-Process -Force } } catch {}
    }

    if ($mutex) { try { $mutex.ReleaseMutex() | Out-Null } catch {}; $mutex.Dispose() }
    Write-Log "Script finalizado (cleanup ok)." "INFO"
}
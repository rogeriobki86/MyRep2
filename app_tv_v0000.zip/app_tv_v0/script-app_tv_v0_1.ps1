



<#
.SYNOPSIS
  Abre Edge com 2 abas (Link1 e Link2) e alterna entre elas a cada N segundos,
  atualizando a aba seguinte em segundo plano antes de trocar (CDP/Page.reload + bringToFront).

.PARAMETER Link1
  URL da aba 1.

.PARAMETER Link2
  URL da aba 2.

.PARAMETER IntervaloSegundos
  Intervalo em segundos entre as trocas (default 50).

.PARAMETER LogPath
  Caminho do arquivo de log (default: %TEMP%\EdgeTabSwap\edge-tabswap.log).

.PARAMETER RunHidden
  Reexecuta o script em segundo plano (janela do PowerShell oculta) e encerra o processo atual.

.NOTES
  Usa Edge (Chromium) com --remote-debugging-port e --user-data-dir (instância isolada).
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$Link1,

    [Parameter(Mandatory=$true)]
    [string]$Link2,

    [ValidateRange(1, 86400)]
    [int]$IntervaloSegundos = 50,

    [string]$LogPath = (Join-Path $env:TEMP "EdgeTabSwap\edge-tabswap.log"),

    [switch]$RunHidden,

    # interno: evita loop de relaunch
    [switch]$HiddenChild
)

# -------------------------
# LOG
# -------------------------
function Initialize-Log {
    param([string]$Path)

    $dir = Split-Path -Parent $Path
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }

    # Rotação simples: se > 5MB, renomeia para .1 (sobrescreve)
    if (Test-Path $Path) {
        $len = (Get-Item $Path).Length
        if ($len -gt 5MB) {
            $bak = "$Path.1"
            if (Test-Path $bak) { Remove-Item $bak -Force -ErrorAction SilentlyContinue }
            Rename-Item -Path $Path -NewName (Split-Path -Leaf $bak) -Force
        }
    }
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","WARN","ERROR")]
        [string]$Level = "INFO"
    )
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
    $line = "[$ts][$Level] $Message"
    Add-Content -Path $LogPath -Value $line
}

Initialize-Log -Path $LogPath
Write-Log "Iniciando script. Link1='$Link1' Link2='$Link2' IntervaloSegundos=$IntervaloSegundos RunHidden=$RunHidden HiddenChild=$HiddenChild"

# -------------------------
# EXECUÇÃO EM SEGUNDO PLANO (CONSOLE OCULTO)
# -------------------------
if ($RunHidden -and -not $HiddenChild) {
    try {
        # Monta argumentos preservando os parâmetros recebidos
        $argList = @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$PSCommandPath`"")
        $argList += @("-Link1", "`"$Link1`"")
        $argList += @("-Link2", "`"$Link2`"")
        $argList += @("-IntervaloSegundos", "$IntervaloSegundos")
        $argList += @("-LogPath", "`"$LogPath`"")
        $argList += @("-HiddenChild")

        Write-Log "Reexecutando em segundo plano (janela oculta). Args: $($argList -join ' ')" "INFO"

        Start-Process -FilePath "powershell.exe" -ArgumentList $argList -WindowStyle Hidden | Out-Null
        Write-Log "Processo em segundo plano iniciado. Encerrando processo atual." "INFO"
    } catch {
        Write-Log "Falha ao reexecutar em segundo plano: $($_.Exception.Message)" "ERROR"
        throw
    }
    exit
}

# -------------------------
# EDGE / CDP
# -------------------------
$DebugPort = 9222
$EdgeProfileDir = Join-Path $env:TEMP "Edge_Automation_Profile_CDP"

function Get-EdgePath {
    $candidatos = @(
        (Join-Path $env:ProgramFiles "Microsoft\Edge\Application\msedge.exe"),
        (Join-Path ${env:ProgramFiles(x86)} "Microsoft\Edge\Application\msedge.exe"),
        "msedge.exe"
    )
    foreach ($p in $candidatos) {
        if ($p -eq "msedge.exe") {
            $cmd = Get-Command msedge.exe -ErrorAction SilentlyContinue
            if ($cmd) { return $cmd.Source }
        } else {
            if (Test-Path $p) { return $p }
        }
    }
    throw "Não encontrei o executável do Edge (msedge.exe)."
}

function Stop-EdgeIfRunning {
    $procs = Get-Process msedge -ErrorAction SilentlyContinue
    if ($procs) {
        Write-Log "Edge detectado em execução ($($procs.Count) processos). Encerrando todos (fecha abas e navegador)..." "WARN"
        $procs | Stop-Process -Force
        Start-Sleep -Seconds 2
        Write-Log "Edge encerrado." "INFO"
    } else {
        Write-Log "Edge não estava em execução." "INFO"
    }
}

function Start-EdgeWithTabsCDP {
    param(
        [string]$EdgeExe,
        [string]$Url1,
        [string]$Url2,
        [int]$Port,
        [string]$ProfileDir
    )

    if (!(Test-Path $ProfileDir)) { New-Item -ItemType Directory -Path $ProfileDir | Out-Null }

    $args = @(
        "--remote-debugging-port=$Port",
        "--user-data-dir=`"$ProfileDir`"",
        "--new-window",
        "`"$Url1`"",
        "`"$Url2`""
    )

    Write-Log "Abrindo Edge em modo CDP (porta $Port) com 2 abas." "INFO"
    Start-Process -FilePath $EdgeExe -ArgumentList $args | Out-Null
}

function Wait-ForCDP {
    param([int]$Port)
    $endpoint = "http://127.0.0.1:$Port/json"
    for ($i=0; $i -lt 200; $i++) {
        try {
            $r = Invoke-RestMethod -Uri $endpoint -Method GET -TimeoutSec 2
            if ($r) { return $true }
        } catch { }
        Start-Sleep -Milliseconds 150
    }
    throw "Não foi possível conectar ao endpoint CDP em $endpoint."
}

function Get-TabWebSocketUrls {
    param(
        [int]$Port,
        [string]$Url1,
        [string]$Url2
    )
    $endpoint = "http://127.0.0.1:$Port/json"
    $pages = Invoke-RestMethod -Uri $endpoint -Method GET

    $tabs = $pages | Where-Object { $_.type -eq "page" -and $_.url -and $_.url -notlike "devtools:*" }
    if (-not $tabs -or $tabs.Count -lt 2) {
        throw "Não consegui identificar 2 abas do tipo 'page' no CDP."
    }

    # tenta casar por URL (pode haver redirecionamento)
    $tab1 = $tabs | Where-Object { $_.url -like "$Url1*" } | Select-Object -First 1
    $tab2 = $tabs | Where-Object { $_.url -like "$Url2*" } | Select-Object -First 1

    if (-not $tab1 -or -not $tab2) {
        # fallback: pega as duas primeiras
        $tab1 = $tabs | Select-Object -First 1
        $tab2 = $tabs | Select-Object -Skip 1 -First 1
        Write-Log "Aviso: não consegui casar URLs exatamente; usando as duas primeiras abas detectadas." "WARN"
    }

    [pscustomobject]@{
        Tab1Url = $tab1.url
        Tab2Url = $tab2.url
        Tab1Ws  = $tab1.webSocketDebuggerUrl
        Tab2Ws  = $tab2.webSocketDebuggerUrl
    }
}

function Connect-WebSocket {
    param([string]$WsUrl)

    Add-Type -AssemblyName System.Net.Http | Out-Null

    $ws = New-Object System.Net.WebSockets.ClientWebSocket
    $cts = New-Object System.Threading.CancellationTokenSource
    $ws.ConnectAsync([Uri]$WsUrl, $cts.Token).Wait()

    if ($ws.State -ne [System.Net.WebSockets.WebSocketState]::Open) {
        throw "Falha ao abrir WebSocket: $WsUrl"
    }
    return $ws
}

function Send-CDP {
    param(
        [System.Net.WebSockets.ClientWebSocket]$Ws,
        [string]$Method,
        [hashtable]$Params = $null,
        [int]$Id
    )

    $payload = @{ id = $Id; method = $Method }
    if ($Params) { $payload.params = $Params }

    $json = ($payload | ConvertTo-Json -Compress)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
    $seg = New-Object System.ArraySegment[byte] -ArgumentList @(,$bytes)

    $ct = [System.Threading.CancellationToken]::None
    $Ws.SendAsync($seg, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $ct).Wait()

    # consome a resposta referente ao Id para não acumular buffer
    $buffer = New-Object byte[] 65536
    while ($true) {
        $recvSeg = New-Object System.ArraySegment[byte] -ArgumentList @(,$buffer)
        $result = $Ws.ReceiveAsync($recvSeg, $ct).Result
        if ($result.Count -gt 0) {
            $text = [System.Text.Encoding]::UTF8.GetString($buffer, 0, $result.Count)
            try {
                $obj = $text | ConvertFrom-Json
                if ($obj.id -eq $Id) { break }
            } catch {
                # pode chegar evento sem id; ignora
            }
        }
        if ($result.EndOfMessage) { break }
    }
}

# -------------------------
# SINGLE INSTANCE (mutex)
# -------------------------
$mutexName = "Global\EdgeTabSwapMutex"
$createdNew = $false
$mutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$createdNew)
if (-not $createdNew) {
    Write-Log "Outra instância do script já está rodando. Encerrando esta instância." "WARN"
    exit 2
}

# -------------------------
# EXECUÇÃO PRINCIPAL
# -------------------------
$ws1 = $null
$ws2 = $null

try {
    Stop-EdgeIfRunning

    $edgeExe = Get-EdgePath
    Start-EdgeWithTabsCDP -EdgeExe $edgeExe -Url1 $Link1 -Url2 $Link2 -Port $DebugPort -ProfileDir $EdgeProfileDir

    Wait-ForCDP -Port $DebugPort
    $tabInfo = Get-TabWebSocketUrls -Port $DebugPort -Url1 $Link1 -Url2 $Link2

    Write-Log "Aba 1 detectada: $($tabInfo.Tab1Url)" "INFO"
    Write-Log "Aba 2 detectada: $($tabInfo.Tab2Url)" "INFO"

    $ws1 = Connect-WebSocket -WsUrl $tabInfo.Tab1Ws
    $ws2 = Connect-WebSocket -WsUrl $tabInfo.Tab2Ws
    Write-Log "WebSockets conectados (Tab1 e Tab2)." "INFO"

    $id = 1

    # Garante início focado na Aba 1 (opcional)
    Send-CDP -Ws $ws1 -Method "Page.bringToFront" -Id $id; $id++
    Write-Log "Iniciando na Aba 1." "INFO"

    while ($true) {
        Start-Sleep -Seconds $IntervaloSegundos

        # Se estiver na aba 1 -> atualizar aba 2 silencioso -> trocar para aba 2
        Write-Log "Ciclo: Atualizar Aba 2 (silencioso) e trocar para Aba 2." "INFO"
        Send-CDP -Ws $ws2 -Method "Page.reload" -Params @{ ignoreCache = $true } -Id $id; $id++
        Send-CDP -Ws $ws2 -Method "Page.bringToFront" -Id $id; $id++

        Start-Sleep -Seconds $IntervaloSegundos

        # Depois -> atualizar aba 1 silencioso -> trocar para aba 1
        Write-Log "Ciclo: Atualizar Aba 1 (silencioso) e trocar para Aba 1." "INFO"
        Send-CDP -Ws $ws1 -Method "Page.reload" -Params @{ ignoreCache = $true } -Id $id; $id++
        Send-CDP -Ws $ws1 -Method "Page.bringToFront" -Id $id; $id++
    }
}
catch {
    Write-Log "Erro fatal: $($_.Exception.Message)" "ERROR"
    throw
}
finally {
    if ($ws1) { $ws1.Dispose() }
    if ($ws2) { $ws2.Dispose() }
    if ($mutex) { $mutex.ReleaseMutex() | Out-Null; $mutex.Dispose() }
    Write-Log "Script finalizado (cleanup
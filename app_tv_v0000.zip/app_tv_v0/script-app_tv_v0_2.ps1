
[CmdletBinding()]
param(
    # Overrides opcionais (se não vierem, usa CONFIG)
    [string]$Link1,
    [string]$Link2,
    [ValidateRange(1,86400)]
    [int]$IntervaloSegundos,
    [string]$LogPath,

    # CDP port: se não informar, detecta uma porta livre automaticamente
    [int]$CDPPort,

    # Execução oculta (bool para permitir default no CONFIG)
    [Nullable[bool]]$RunHidden,

    # LOG rotation overrides
    [ValidateRange(1,1024)]
    [int]$MaxLogSizeMB,
    [ValidateRange(1,999)]
    [int]$MaxLogFiles,
    [Nullable[bool]]$RotateDaily,

    # Parar loop (modo "sinalizar parada")
    [switch]$Stop,
    [string]$StopSignalPath,

    # Ao parar, encerrar Edge?
    [Nullable[bool]]$FecharEdgeAoParar,

    # interno: evita loop de relaunch hidden
    [switch]$HiddenChild
)

# ==========================================================
# CONFIG (defaults diretos no código)
# ==========================================================
$CONFIG = [ordered]@{
    Link1              = "https://www.microsoft.com/pt-br/edge/update/144/cm?form=MT01AD&channel=stable&version=145.0.3800.97&sg=2&cs=350088316"   # <- coloque sua URL 1
    Link2              = "https://vendaonline.bradescard.com.br/?canal=531&origem=913&tpopto=3&ptovda=17&campa=068&prod=7837"   # <- coloque sua URL 2
    IntervaloSegundos  = 50

    LogPath            = (Join-Path $env:TEMP "EdgeTabSwap\edge-tabswap.log")

    # Rotação de log
    MaxLogSizeMB       = 5          # roda quando passar disso
    MaxLogFiles        = 10         # mantém .1 até .10
    RotateDaily        = $true      # roda quando muda o dia

    # Execução em segundo plano (PowerShell oculto)
    RunHidden          = $true

    # CDP port: 0 = auto (livre)
    CDPPort            = 0

    # Sinal de parada (arquivo)
    StopSignalPath     = ""         # vazio => auto baseado no diretório do log

    # Ao parar, fecha Edge?
    FecharEdgeAoParar  = $true
}
# ==========================================================

# --------- aplica overrides vindos da linha de comando ----------
if ($PSBoundParameters.ContainsKey('Link1') -and $Link1) { $CONFIG.Link1 = $Link1 }
if ($PSBoundParameters.ContainsKey('Link2') -and $Link2) { $CONFIG.Link2 = $Link2 }
if ($PSBoundParameters.ContainsKey('IntervaloSegundos') -and $IntervaloSegundos) { $CONFIG.IntervaloSegundos = $IntervaloSegundos }
if ($PSBoundParameters.ContainsKey('LogPath') -and $LogPath) { $CONFIG.LogPath = $LogPath }

if ($PSBoundParameters.ContainsKey('CDPPort') -and $CDPPort) { $CONFIG.CDPPort = $CDPPort }

if ($PSBoundParameters.ContainsKey('RunHidden') -and $null -ne $RunHidden) { $CONFIG.RunHidden = [bool]$RunHidden }

if ($PSBoundParameters.ContainsKey('MaxLogSizeMB') -and $MaxLogSizeMB) { $CONFIG.MaxLogSizeMB = $MaxLogSizeMB }
if ($PSBoundParameters.ContainsKey('MaxLogFiles') -and $MaxLogFiles) { $CONFIG.MaxLogFiles = $MaxLogFiles }
if ($PSBoundParameters.ContainsKey('RotateDaily') -and $null -ne $RotateDaily) { $CONFIG.RotateDaily = [bool]$RotateDaily }

if ($PSBoundParameters.ContainsKey('StopSignalPath') -and $StopSignalPath) { $CONFIG.StopSignalPath = $StopSignalPath }
if ($PSBoundParameters.ContainsKey('FecharEdgeAoParar') -and $null -ne $FecharEdgeAoParar) { $CONFIG.FecharEdgeAoParar = [bool]$FecharEdgeAoParar }

# --------- resolve StopSignalPath default ----------
if ([string]::IsNullOrWhiteSpace($CONFIG.StopSignalPath)) {
    $CONFIG.StopSignalPath = Join-Path (Split-Path -Parent $CONFIG.LogPath) "stop.signal"
}

# --------- se for apenas sinalizar parada, cria o arquivo e sai ----------
if ($Stop) {
    $dir = Split-Path -Parent $CONFIG.StopSignalPath
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
    Set-Content -Path $CONFIG.StopSignalPath -Value ("STOP " + (Get-Date).ToString("s"))
    Write-Host "Sinal de parada criado em: $($CONFIG.StopSignalPath)"
    exit 0
}

# --------- valida obrigatórios após mesclagem ----------
if (-not $CONFIG.Link1 -or $CONFIG.Link1 -eq "LINK_1") { throw "CONFIG.Link1 não definido. Preencha no CONFIG ou passe -Link1." }
if (-not $CONFIG.Link2 -or $CONFIG.Link2 -eq "LINK_2") { throw "CONFIG.Link2 não definido. Preencha no CONFIG ou passe -Link2." }

# --------- aplica config final ----------
$Link1             = $CONFIG.Link1
$Link2             = $CONFIG.Link2
$IntervaloSegundos = $CONFIG.IntervaloSegundos
$LogPath           = $CONFIG.LogPath
$RunHidden         = $CONFIG.RunHidden
$MaxLogSizeMB      = $CONFIG.MaxLogSizeMB
$MaxLogFiles       = $CONFIG.MaxLogFiles
$RotateDaily       = $CONFIG.RotateDaily
$StopSignalPath    = $CONFIG.StopSignalPath
$FecharEdgeAoParar = $CONFIG.FecharEdgeAoParar

# -------------------------
# LOG + ROTAÇÃO
# -------------------------
$script:CurrentLogDay = (Get-Date).ToString("yyyyMMdd")

function Ensure-Dir([string]$path) {
    $d = Split-Path -Parent $path
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d | Out-Null }
}

function Rotate-LogIfNeeded {
    Ensure-Dir $LogPath

    $needRotate = $false

    if (Test-Path $LogPath) {
        # por tamanho
        $len = (Get-Item $LogPath).Length
        if ($len -ge ($MaxLogSizeMB * 1MB)) { $needRotate = $true }

        # por dia (opcional)
        if ($RotateDaily) {
            $today = (Get-Date).ToString("yyyyMMdd")
            if ($today -ne $script:CurrentLogDay) { $needRotate = $true }
        }
    }

    if (-not $needRotate) { return }

    # Rotação estilo .1 .. .N (mantém últimos MaxLogFiles)
    # (padrão de rotação por rename / arquivos antigos) [1](https://blog.anthonymiller.pro/2025/09/powershell-logging-part-2-rotating-your.html)[2](https://stackoverflow.com/questions/43593248/powershell-script-to-logrotate-logs)
    for ($i = $MaxLogFiles; $i -ge 1; $i--) {
        $src = "$LogPath.$i"
        $dst = "$LogPath." + ($i + 1)
        if (Test-Path $src) {
            if ($i -eq $MaxLogFiles) {
                Remove-Item $src -Force -ErrorAction SilentlyContinue
            } else {
                Rename-Item -Path $src -NewName (Split-Path -Leaf $dst) -Force
            }
        }
    }

    if (Test-Path $LogPath) {
        Rename-Item -Path $LogPath -NewName (Split-Path -Leaf "$LogPath.1") -Force
    }

    $script:CurrentLogDay = (Get-Date).ToString("yyyyMMdd")
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet("INFO","WARN","ERROR")]
        [string]$Level = "INFO"
    )
    Rotate-LogIfNeeded
    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss.fff")
    Add-Content -Path $LogPath -Value "[$ts][$Level] $Message"
}

# -------------------------
# CONTROLE DE PARADA
# -------------------------
function Should-Stop {
    return (Test-Path $StopSignalPath)
}

function Sleep-Interruptible([int]$seconds) {
    for ($i=0; $i -lt $seconds; $i++) {
        if (Should-Stop) { return $false }
        Start-Sleep -Seconds 1
    }
    return $true
}

# -------------------------
# EXECUÇÃO EM SEGUNDO PLANO (OCULTO